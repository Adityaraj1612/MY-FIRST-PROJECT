// Detect geolocation for hospitals
document.getElementById('detect-location').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default button behavior
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showNearbyHospitals, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});

// Show nearby hospitals once location is obtained
function showNearbyHospitals(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;

    // Dummy hospital data with latitude and longitude
    const hospitalData = [
        { name: "Alpha Chandigarh Hospital", distance: "1.9 km", lat: 30.7415, lng: 76.7681 },
        { name: "Health Sure", distance: "2.8 km", lat: 30.7791306, lng: 76.5594133 },
        { name: "Civil Hospital", distance: "5.8 km", lat: 30.6942, lng: 76.7410 }
    ];

    const hospitalList = document.getElementById('hospital-data');
    hospitalList.innerHTML = ''; // Clear any existing content

    hospitalData.forEach(hospital => {
        const li = document.createElement('li');
        li.innerHTML = `
            <a href="https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=${hospital.lat},${hospital.lng}" target="_blank">
                ${hospital.name} - ${hospital.distance}
            </a>
        `;
        hospitalList.appendChild(li);
    });
}

// Handle errors in geolocation
function showError(error) {
    switch (error.code) {
        case error.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
        case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
        case error.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
            break;
    }
}

// Emergency button: redirect to Google Maps with user's location
document.getElementById('emergency-btn').addEventListener('click', function () {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToGoogleMaps, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});

function redirectToGoogleMaps(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;

    // Redirect to Google Maps, centered on the user's current location
    const googleMapsUrl = `https://www.google.com/maps/@${latitude},${longitude},15z`;
    window.open(googleMapsUrl, '_blank');
}

// Doctor info display functionality
document.getElementById('doctor-btn').addEventListener('click', function() {
    document.getElementById('emergency-info').style.display = 'none';
    document.getElementById('doctor-info').style.display = 'block';

    const doctorData = [
        { name: "Dr. Pratima Duggal", specialty: "Laser and implant" },
        { name: "Dr Sunandan Sood", specialty: "Retinal surgery" }
    ];

    const doctorList = document.getElementById('doctor-data');
    doctorList.innerHTML = "";
    doctorData.forEach(doctor => {
        const li = document.createElement('li');
        li.textContent = `${doctor.name} - Specialty: ${doctor.specialty}`;
        doctorList.appendChild(li);
    });
});

// Simulate sending location to a dummy page
document.getElementById('alert-btn').addEventListener('click', function () {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(sendLocationToDummyPage, showError);
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});

function sendLocationToDummyPage(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;

    const dummyPageURL = `https://example.com/dummy-page?lat=${latitude}&long=${longitude}`;
    
    // Simulate a form submission to send location data
    window.location.href = dummyPageURL;

    // Show the message to the user
    alert("You will be contacted soon.");
}

// Function to change the language
function changeLanguage(lang) {
    document.querySelectorAll("[data-lang]").forEach(element => {
        const key = element.getAttribute("data-lang");
        element.textContent = translations[lang][key];
    });
}

// Detect language change from the dropdown
document.getElementById('language-selector').addEventListener('change', function () {
    const selectedLang = this.value;
    changeLanguage(selectedLang);
});

// Initial language set to English
window.onload = function() {
    changeLanguage('en'); // Default to English when the page loads
};

// Language translations
const translations = {
    en: {
        "hero-title": "Find Nearby Hospitals Automatically",
        "hero-desc": "HEALME provides instant access to nearby hospitals and specialist doctors, along with real-time bed availability, all in your preferred language.",
        "use-location": "Use My Location",
        "language-supported": "Languages supported: English, Hindi, Punjabi, Tamil, Telugu",
        "nearby-hospitals": "Nearby Hospitals",
        "emergency": "Emergency",
        "doctors": "Doctors",
        "signin": "Sign In",
    },
    hi: {
        "hero-title": "स्वचालित रूप से निकटतम अस्पताल खोजें",
        "hero-desc": "HEALME निकटतम अस्पतालों और विशेषज्ञ डॉक्टरों तक त्वरित पहुँच प्रदान करता है, साथ ही वास्तविक समय की बिस्तर उपलब्धता, आपकी पसंदीदा भाषा में।",
        "use-location": "मेरी स्थिति का उपयोग करें",
        "language-supported": "समर्थित भाषाएँ: अंग्रेजी, हिंदी, पंजाबी, तमिल, तेलुगु",
        "nearby-hospitals": "नजदीकी अस्पताल",
        "emergency": "आपातकाल",
        "doctors": "डॉक्टर्स",
        "signin": "साइन इन करें",
    },
    pa: {
        "hero-title": "ਆਪਣੇ ਆਸ-ਪਾਸ ਦੇ ਹਸਪਤਾਲਾਂ ਨੂੰ ਆਪਣੇ ਆਪ ਲੱਭੋ",
        "hero-desc": "HEALME ਨੇੜੇ ਦੇ ਹਸਪਤਾਲਾਂ ਅਤੇ ਵਿਸ਼ੇਸ਼ਤਾਜ਼ ਡਾਕਟਰਾਂ ਤੱਕ ਤੁਰੰਤ ਪਹੁੰਚ ਮੁਹੈਆ ਕਰਦਾ ਹੈ, ਜਿਨ੍ਹਾਂ ਵਿੱਚ ਵਰਤਮਾਨ ਬਿਸਤਰੀ ਉਪਲਬਧਤਾ ਦੇ ਨਾਲ, ਤੁਹਾਡੀ ਮਨਪਸੰਦ ਭਾਸ਼ਾ ਵਿੱਚ।",
        "use-location": "ਮੇਰੀ ਸਥਿਤੀ ਦੀ ਵਰਤੋਂ ਕਰੋ",
        "language-supported": "ਸਮਰਥਿਤ ਭਾਸ਼ਾਵਾਂ: ਅੰਗਰੇਜ਼ੀ, ਹਿੰਦੀ, ਪੰਜਾਬੀ, ਤਮਿਲ, ਤੇਲਗੂ",
        "nearby-hospitals": "ਨੇੜੇ ਦੇ ਹਸਪਤਾਲ",
        "emergency": "ਐਮਰਜੈਂਸੀ",
        "doctors": "ਡਾਕਟਰ",
        "signin": "ਸਾਈਨ ਇਨ ਕਰੋ",
    },
    // Add more languages as needed
};
